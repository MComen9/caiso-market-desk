# CAISO 价格预测研究 · 可复现运行

本目录是真实执行过的本地 Python 模型实验。输入是本平台已归档的 OASIS 三枢纽价格，输出包括模型比较、独立留出评价、前瞻预测、版本及策略模拟可读数据。它不调用大模型生成价格，不补造缺失行情，不发送交易。

## 当前实验结果

已运行 9 个候选配置 × 42 个日度滚动起点 × 2 个预测目标。每个起点重新拟合，仅使用目标日 D 之前至少两天的完整 PT 日；目标是小时日前价 DA 和四个完整 FMM 的小时均价减 DA。

验证期选择 **DA：Ridge α=10；价差：同小时 28 日均值**。模型选择冻结后，14 日留出集出现退化，因此当前版本明确为 **研究版，未通过基线检查**，不能表述为已证实的交易优势。

| 目标 | 验证 MAE | 验证基线 MAE | 留出 MAE | 留出基线 MAE |
|---|---:|---:|---:|---:|
| DA，USD/MWh | 10.5694 | 12.1430（14 日均值） | 9.9305 | 7.1124（14 日均值） |
| FMM−DA，USD/MWh | 9.2700 | 10.0832（零价差） | 9.0575 | 8.6196（零价差） |

留出集价差方向准确率为 51.09%，固定预测负价差为 50.89%；这不足以证明有效方向优势。标称 80% 的经验残差区间，留出覆盖率分别为 DA 75.00%、价差 71.33%。区间不能当作保证概率。

这些数值是归档数据上的研究计算，不是实际交易回执或完整结算收益。没有根据已看过的留出结果重新挑选排行榜赢家。

## 运行

从仓库根目录执行：

```bash
python -m pip install -r research/requirements.txt
python research/forecast_pipeline.py
python research/test_forecast_pipeline.py
```

默认读取 `data/strategy-history.json`，结果写到 `public/data/forecast-lab/`。当需要明确目标日时：

```bash
python research/forecast_pipeline.py --forecast-date 2026-10-30
```

显式目标日的前一日 PT 09:55 已过去时，脚本拒绝生成“可在该截点前使用”的预测。省略目标日则先选择尚未错过决策截点的后续交付日，然后检查数据新鲜度：**目标日 D−2 必须具有全部枢纽、全部 UTC 小时的完整 DA/FMM 配对**。任一缺失都会停止，不会把最新完整日的缺失当作普通可填补特征。

例如，当前归档截至 Oct28，因此支持的本次 Oct30 前瞻在当时截止时间前已生成；一旦需要预测 Oct31，就必须先补齐 Oct29 全日数据，不能继续从 Oct28 的旧归档生成。当前冻结实验要求归档覆盖 Sep3–Oct28；更换训练样本和评价周期时应建立新的实验协议，不能不加说明地把旧留出窗口反复用于调参。

**复现已冻结模拟与重新训练是两项不同操作。** 已保存的 `forecast-forward.json`、`forecast-history.json` 以及 Python 桥接策略输入可以随时读取和重放，不需要修改生成时间或重新训练。上述完整研究命令会重新拟合并生成新的前瞻批次，因而必须同时满足尚未经过的决策截点和最新 D−2 完整数据要求。错过旧日期后，应使用冻结输入复查旧结果，或更新归档、明确新协议再运行；不能回填旧的 `issuedAt`。

依赖已在 Python 3.12.14、NumPy 2.3.5、scikit-learn 1.8.0、SciPy 1.17.0 运行。树随机种子 42；学习器没有随机交叉验证或内部随机早停验证集。每次运行的实际生成时间和内容摘要都会更新；预测数值在相同环境、样本和设置下可复现。

## 时间拆分

| 用途 | PT 日期 | 规则 |
|---|---|---|
| 原始输入 | Sep3–Oct28 | 56 日、3 枢纽、4,032 个完整配对小时 |
| 有可用滞后特征的训练行 | Sep10 起 | lag14 等早期缺值只在当日训练集内拟合中位数 |
| 滚动残差预热 | Sep17–Sep24 | 给验证诊断提供此前已发生的滚动残差 |
| 模型和参数选择 | Sep25–Oct6 | 两目标各自按 MAE 选择；距最优 1% 内偏好预定顺序更简单的模型 |
| 隔离日 | Oct7 | 不参与选择或校准 |
| 不确定性校准 | Oct8–Oct13 | 每枢纽 144 个冻结模型滚动残差 |
| 隔离日 | Oct14 | 保证 Oct15 决策截点前校准标签满足 D−2 |
| 最终留出 | Oct15–Oct28 | 14 日，1,008 行；只报告，不调参 |
| 本次前瞻 | Oct30 | 72 小时节点预测；使用实际生成时间、训练截至 Oct28 |

每日拟合可以使用此前已观察到的留出日标签；这是预先规定的扩展窗口运行方式，不会用未来测试标签预测较早时段。超参数、候选选择和校准窗口在留出前冻结。

## 特征和候选

特征包括枢纽、当地小时、星期、DA 和价差的 2/3/7/14 日滞后、7/14/28 日同小时均值与标准差、D−2 日内汇总、其他枢纽同小时 D−2 滞后。所有滞后以当地日期构造，唯一键仍为 UTC 小时。秋季重复小时在同一天的历史同小时统计中先取日内均值，不当成两个独立日；实际预测按 23/24/25 小时枚举。

候选为零价差、上周同小时、7/14/28 日均值、Ridge α=10/100、受限复杂度梯度提升树、受限复杂度 Extra Trees。没有为了使用更复杂算法而强制选树模型。

当前 OASIS 负荷/风光和 Outlook 只有两日快照，无法覆盖训练期，也没有完整历史发布批次；GridStatus 没有可用已获取数据；RTD 本地仅八日归档且与 FMM 目标不同。这些数据经过覆盖和时点审查后排除，不直接混入训练制造信息泄漏。

## 文件契约

| 文件 | 用途 |
|---|---|
| `report.json` | 数据覆盖、选择规则、候选比较、留出指标、基线检查、来源和限制 |
| `forecast-forward.json` | 真正于目标前生成的 72 个前瞻预测；可接入平台标准预测批次 |
| `forecast-history.json` | 1,008 个独立留出重建预测；只用于明确标记的历史研究 |
| `all-walk-forward.json` | 全部滚动诊断记录；Oct8 以前的已选模型记录标记 `selectionEligibleAtAsOf=false`，属于调参样本 |
| `candidate-predictions.json` | 每个候选的原始滚动预测，供独立复算指标 |
| `models.json` | 最终参数、特征、输入摘要、预处理与可读模型状态；不使用 pickle 加载 |
| `predictions.csv` | 留出和前瞻逐小时明细 |

`issuedAt` 在所有输出中都是真实当前生成时间。历史文件的 `decisionAsOfUtc` 是研究截点，不能被改名为当时已发布的预测。`sampleCount` 是该起点可用的监督训练小时行数，基线实际使用其同节点同小时窗口；`calibrationCount` 是该枢纽残差数。前瞻实际价格为空。

策略输入与运行方式另见同目录的 Python 策略桥接文件及输出说明；前瞻只产生计划和条件预期值，实际值到齐后才能结算研究盈亏。

## 下一次改进如何评价

这次验证期与留出期存在明显价格和价差分布变化。下一次可以在新协议中比较更短训练窗口、稳健损失、保守基线组合，以及加入有历史发布批次的负荷和风光信息。已看过的 Oct15–28 不能再充当新的独立测试；后续改进必须在新未来样本上前瞻归档和评价。

方法参考采用 scikit-learn 官方文档：

- https://scikit-learn.org/stable/auto_examples/applications/plot_time_series_lagged_features.html
- https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.Ridge.html
- https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.HistGradientBoostingRegressor.html


See research/PYTHON_INPUT.md for the strategy input and simulation commands. Optional TypeScript parity checks require npm install, then python research/test_strategy_bridge.py --export-parity and node research/test_strategy_parity.mjs.
