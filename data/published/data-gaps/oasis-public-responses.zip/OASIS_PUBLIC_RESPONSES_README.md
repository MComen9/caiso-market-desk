# 本轮 OASIS 原始响应与回执

快照标签：delivery-snapshot。包含 273 份逐请求回执、271 份已保存响应；失败回执也保留。

仅收录本轮 gap-acquisition 的直接响应和回执；不包含其他运行环境文件。HTTP 200、ZIP后缀或存在文件都不表示业务成功，须查看回执 status/error。失败时可能没有响应正文。

解压到代码交付包同一根目录，即恢复脚本需要的原始响应位置。oasis-public-responses-manifest.json 对全部负载文件列出 SHA-256 和字节数；清单自身不进行不可能的自哈希，整个 ZIP 的 SHA-256 由打包命令输出。

本包不包含原有52份价格源缓存；不能据此声称旧180天原生价格分量已经从全部旧源完整重现。新采集源可以复核；旧原生价格规范化表及其审计由 companion delivery 包提供。

```bash
python research/inspect_data_gaps.py verify /path/to/oasis-public-responses.zip
python research/inspect_data_gaps.py qa-nodes
```

快照不等于所有数据缺口已解决，也不等于历史可用时间已得到证明。
