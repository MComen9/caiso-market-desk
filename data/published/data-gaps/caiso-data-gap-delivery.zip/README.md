# CAISO 本次数据补齐交付

生成于 2026-10-30T07:45:02.955Z；快照标签：**delivery-snapshot**。完整业务说明和数据目录见 `public/data/data-gaps/DATA_GAPS_README.md` 与 `catalog.json`。

## 两个包分别包含什么

- `caiso-data-gap-delivery.zip`：规范化 JSON/GZ、审计与冲突报告、必要读取/采集/整理/验证代码、冻结的180天小时价格基线、5个既有 TypeScript 标准化模块，以及最小依赖说明。
- `oasis-public-responses.zip`：本轮 273 份公开 OASIS 请求回执及 271 份已保存响应，包括失败记录。只取本轮公开采集目录，没有其他运行环境文件。

两个 ZIP 均小于25 MiB。每包的清单包含全部负载文件的 SHA-256 与字节数；清单自身除外，整个 ZIP 的 SHA-256 由打包命令输出。路径、大小与ZIP CRC均校验。天气和结算证据各保留一个嵌套 ZIP，官方原件不重复铺开。

## 解压与基本复核

在一个空工作目录保存两个 ZIP，然后执行：

```bash
python -m zipfile -e caiso-data-gap-delivery.zip caiso-data-gap
python caiso-data-gap/research/inspect_data_gaps.py verify caiso-data-gap-delivery.zip oasis-public-responses.zip
python -m zipfile -e oasis-public-responses.zip caiso-data-gap
cd caiso-data-gap
python research/inspect_data_gaps.py list
python research/inspect_data_gaps.py head official-forecast-history-180d --limit 3
python research/inspect_data_gaps.py head tradable-node-map-180d --limit 3
python -m unittest discover -s research -p test_missing_data_integrity.py -v
python research/inspect_data_gaps.py qa-nodes
```

`qa-nodes`直接用标准库读原始ZIP/CSV，独立比较官方峰谷日历、实际返回的节点与已交付原生参考价格，不导入新整理器。它核对交付的冲突报告；成功表示报告复核一致，**不表示节点冲突已解决或已获交易授权**。全部布尔、null和原始符号按声明字段保留。

## 独立 TypeScript 全值核验

需要 Node.js 18+。包内最小package.json只固定 `fflate@0.8.2` 与 `typescript@5.9.3`，不安装完整网站依赖。依赖安装需要网络，核验本身离线。

```bash
npm install --ignore-scripts
node research/verify_missing_forecasts.mjs
```

该核验重读24份本轮预测响应，经过既有 TypeScript 标准化逻辑比较180天预测面板。它会在解压副本更新核验JSON，不改模型。

## 天气与结算证据

读取器可直接从嵌套ZIP读取JSON，例如：

```bash
python research/inspect_data_gaps.py head weather-evidence/generator-outages-am-20261029.json --limit 3
python research/inspect_data_gaps.py verify public/data/data-gaps/weather-evidence/weather-outage-evidence.zip public/data/data-gaps/settlement-evidence/download-evidence.zip
```

如需打开原件、运行天气核验或重新生成目录，先解压两份证据包到各自目录：

```bash
python -m zipfile -e public/data/data-gaps/weather-evidence/weather-outage-evidence.zip public/data/data-gaps/weather-evidence
python -m zipfile -e public/data/data-gaps/settlement-evidence/download-evidence.zip public/data/data-gaps/settlement-evidence
python research/verify_weather_evidence.py
```

## 可重建范围与限制

解压两包及证据后可运行 `python research/build_missing_data.py`、`python research/build_data_gap_catalog.py`。这些命令重建本次新增表，不会训练模型。生成时间更新会改变压缩字节；需按字段和数值核验，不能要求重建ZIP与原包逐字节相同。

包含 `data/strategy-history-expanded.json` 作为原有180天小时基线，包含 `price-components-180d.json.gz` 作为已经回收的原生价格分量。**本轮原始包没有复制原有52份价格源缓存**，因此 `recover_price_components.py` 是方法代码，不可仅凭这两包重新恢复全部旧源；它需要原项目中相应旧缓存及bootstrap。本文不声称全应用、冻结模型和全部历史源都已打包。

预测当前历史值、XML源消息时间、模型初始化时间和原始可公开时间是不同概念。读取、哈希通过、字段齐全和消息早于截点都不自动批准因果回测。节点冲突、完整结算/FM、费用及账户资料的限制继续生效。

## 再采集和再次打包

在线采集代码保留原限流；运行 fetch 脚本会请求公开服务。只做离线核验无需运行它们。核心Python工具仅需Python3.11+标准库和IANA时区库；重取XLSX才需要 `pip install -r requirements-optional.txt`，缺IANA时区的系统可安装 `tzdata`。

```bash
python research/package_data_gaps.py --output-dir /path/to/trial-packages
# 收集、整理、QA结束且源文件静止后，再由交付负责人执行：
python research/package_data_gaps.py --final
```

`--final`要求打包过程中源文件和请求回执列表保持稳定；它标记本次交付快照，不宣称所有研究缺口已补齐。
